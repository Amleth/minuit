from lark import Lark

grammar = r"""
    start: pattern_lane_def*
    pattern_lane_def: (pattern_name ".r" "=" rhythm_lane_values) | (pattern_name ".p" "=" c+)
    c: CHAR
    pattern_name: /P[0-9]+/
    pattern_type: /[pr]/
    rhythm_lane_values: value+
    value: INT | FRACTION
    INT: /\d+/
    FRACTION: INT "/" INT
    CHAR: /\S/
    %import common.WS
    %ignore WS
"""

parser = Lark(grammar, start='start')
tree = parser.parse(r"""
P0.r = 4 34 55 4/3 5
P0.p = 1 2 3
P1.p = 45678
""")
print(tree.pretty())

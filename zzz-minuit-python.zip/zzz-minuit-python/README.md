# Minuit

## Inspirations

- https://tidalcycles.org/
- https://opusmodus.com/
- https://oxiinstruments.com/oxi-one
- https://squarp.net/hapax/
- https://510k.myshopify.com/products/seqund-au-vst-vst3-sequencer
- https://en.wikipedia.org/wiki/FastTracker_2
- https://dirtywave.com/
- https://xor-electronics.com/nerdseq/
- https://100r.co/site/orca.html
- https://doc.sccode.org/Tutorials/A-Practical-Guide/PG_01_Introduction.html
- https://marionietoworld.com/
- https://squarp.net/hapax/manual/modefx/
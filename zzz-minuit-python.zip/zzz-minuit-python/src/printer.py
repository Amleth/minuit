from pathlib import Path


def print_title(name: str, path: Path):
    print("")
    print("🌲" * 42)
    print(f"🌲 SCORE NAME: {name} ({path})")
    print("🌲" * 42)
    print("")

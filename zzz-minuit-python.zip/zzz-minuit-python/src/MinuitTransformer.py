from lark import Transformer, v_args
from .MinuitDomain import Pattern, PitchLane, PitchToken, RhythmLane, RhythmToken


@v_args(inline=True)
class MinuitTransformer(Transformer):
    def start(self, *patterns):
        for pattern in patterns:
            print(pattern)
        # # Group patterns
        #  by name
        # pattern_dict = {}
        # for pattern in patterns:
        #     if pattern.name not in pattern_dict:
        #         pattern_dict[pattern.name] = pattern
        #     else:
        #         existing_pattern = pattern_dict[pattern.name]
        #         if pattern.pitch_lane:
        #             existing_pattern.pitch_lane = pattern.pitch_lane
        #         if pattern.rhythm_lane:
        #             existing_pattern.rhythm_lane = pattern.rhythm_lane
        # return Score(list(pattern_dict.values()))

    # def pattern(self, name, _, lane_type, ___, lane):
    #     pattern = Pattern(name=name)
    #     if lane_type == ".p":
    #         pattern.pitch_lane = lane
    #     elif lane_type == ".r":
    #         pattern.rhythm_lane = lane
    #     return pattern

    # def pattern_name(self, token):
    #     return token.value

    # def pitch_lane(self, *tokens):
    #     return PitchLane(tokens)

    # def pitch_token(self, token):
    #     return PitchToken(token)

    # def rhythm_lane(self, *tokens):
    #     return RhythmLane(tokens)

    # def rhythm_token(self, token):
    #     return RhythmToken(int(token))

    # def INT(self, token):
    #     return int(token)

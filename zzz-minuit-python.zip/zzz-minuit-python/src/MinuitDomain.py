from dataclasses import dataclass
from typing import List, Union


@dataclass
class PitchToken:
    value: str


@dataclass
class RhythmToken:
    value: int


@dataclass
class PitchLane:
    tokens: List[PitchToken]


@dataclass
class RhythmLane:
    tokens: List[RhythmToken]


@dataclass
class Pattern:
    name: str
    pitch_lane: PitchLane = None
    rhythm_lane: RhythmLane = None


@dataclass
class Score:
    patterns: List[Pattern]
